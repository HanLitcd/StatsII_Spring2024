# quanteda Cheatsheet materials

The cheatsheet itself is in Powerpoint; the file plot_cheatsheet.R in the folder "code" creates the images which are saved in the "plots" folder.

To save the cheatsheet as a PDF file, you need to choose "US Letter" under the Paper Size options. 

The cheatsheet is also published at the [RStudio website](https://www.rstudio.com/resources/cheatsheets/).



